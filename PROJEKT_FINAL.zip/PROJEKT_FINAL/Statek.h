#ifndef STATEK_H
#define STATEK_H

#include <vector>

class Statek {
public:
    int dlugosc;
    std::vector<std::pair<int, int>> pola; // Lista pól, które zajmuje statek
    
    Statek(int dlugosc);
    void dodajPole(int x, int y);
};

#endif
