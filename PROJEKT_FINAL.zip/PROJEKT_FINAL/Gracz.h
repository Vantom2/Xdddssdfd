#ifndef GRACZ_H
#define GRACZ_H

#include <string>
#include "Plansza.h"

class Gracz {
public:
    std::string imie;
    Plansza plansza;
    
    Gracz(std::string imie);
    void ustawStatkiRęcznie(); 
    bool strzelajDoPrzeciwnika(int x, int y);
    bool czyWszystkieStatkiZniszczone();
};

#endif
