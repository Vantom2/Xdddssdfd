#include "Plansza.h"
#include <iostream>

Plansza::Plansza() {
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            plansza[i][j] = '~';
        }
    }
}

void Plansza::wyswietlPlansze(bool widokPrzeciwnika) {
    std::cout << "   ";
    for (int i = 0; i < 10; i++) {
        std::cout << i << " ";
    }
    std::cout << std::endl;

    for (int i = 0; i < 10; i++) {
        std::cout << i << "  ";
        for (int j = 0; j < 10; j++) {
            if (widokPrzeciwnika && plansza[i][j] == 'O') {
                std::cout << "~ ";
            } else {
                std::cout << plansza[i][j] << " ";
            }
        }
        std::cout << std::endl;
    }
}
bool Plansza::sprawdzOkolice(int x, int y, int dlugosc, char orientacja) {
    if (orientacja == 'H') { // Poziomo
        for (int i = -1; i <= dlugosc; i++) {
            for (int j = -1; j <= 1; j++) {
                int nx = x + i;
                int ny = y + j;
                if (nx >= 0 && nx < 10 && ny >= 0 && ny < 10 && plansza[ny][nx] != '~') {
                    return false;
                }
            }
        }
    } else if (orientacja == 'V') { // Pionowo
        for (int i = -1; i <= dlugosc; i++) {
            for (int j = -1; j <= 1; j++) {
                int nx = x + j;
                int ny = y + i;
                if (nx >= 0 && nx < 10 && ny >= 0 && ny < 10 && plansza[ny][nx] != '~') {
                    return false;
                }
            }
        }
    }
    return true;
}


bool Plansza::ustawStatek(int x, int y, int dlugosc, char orientacja) {
    // Sprawdź, czy statek zmieści się na planszy
    if ((orientacja == 'H' && (x + dlugosc - 1) >= 10) || (orientacja == 'V' && (y + dlugosc - 1) >= 10)) {
        return false;
    }

    // Sprawdź, czy okolice są wolne
    if (!sprawdzOkolice(x, y, dlugosc, orientacja)) {
        return false;
    }

    // Ustaw statek
    if (orientacja == 'H') {
        for (int i = 0; i < dlugosc; i++) {
            plansza[y][x + i] = 'O';
        }
    } else if (orientacja == 'V') {
        for (int i = 0; i < dlugosc; i++) {
            plansza[y + i][x] = 'O';
        }
    }

    return true;
}


bool Plansza::strzelaj(int x, int y) {
    if (plansza[y][x] == 'O') {
        plansza[y][x] = 'X';
        std::cout << "Trafiony!\n";
        return true;
    } else if (plansza[y][x] == '~') {
        plansza[y][x] = 'P';
        std::cout << "Pudło!\n";
        return false;
    } else {
        std::cout << "To pole zostało już trafione! Tracisz turę.\n";
        return false;
    }
}

bool Plansza::sprawdzCzyWszystkieStatkiZniszczone() {
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            if (plansza[i][j] == 'O') {
                return false;
            }
        }
    }
    return true;
}
