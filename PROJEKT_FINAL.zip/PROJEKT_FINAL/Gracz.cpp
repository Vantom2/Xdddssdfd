#include "Gracz.h"
#include <iostream>
#include <vector>

Gracz::Gracz(std::string imie) {
    this->imie = imie;
}

void Gracz::ustawStatkiRęcznie() {
    std::vector<int> statki = {4, 3, 3, 2, 2, 2, 1, 1, 1, 1}; 
    for (int i = 0; i < statki.size(); i++) {
        bool ustawiono = false;
        while (!ustawiono) {
            int x, y;
            char orientacja;
            std::cout << "Ustaw statek o dlugosci " << statki[i] << " (wpisz wspolrzedne x, y oraz orientacje [POZIOMO(H)/PIONOWO(V)]): ";
            std::cin >> x >> y >> orientacja;

            
            if (plansza.ustawStatek(x, y, statki[i], orientacja)) {
                ustawiono = true;
                std::cout << "Statek ustawiony pomyślnie!\n";
                plansza.wyswietlPlansze(false);  
            } else {
                std::cout << "Nie udało się ustawić statku. Spróbuj ponownie.\n";
            }
        }
    }
}

bool Gracz::strzelajDoPrzeciwnika(int x, int y) {
    return plansza.strzelaj(x, y);
}

bool Gracz::czyWszystkieStatkiZniszczone() {
    return plansza.sprawdzCzyWszystkieStatkiZniszczone();
}
