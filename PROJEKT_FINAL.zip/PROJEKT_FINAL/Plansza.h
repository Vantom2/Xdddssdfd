#ifndef PLANSZA_H
#define PLANSZA_H

class Plansza {
public:
    char plansza[10][10];
    
    Plansza();
    void wyswietlPlansze(bool widokPrzeciwnika = false);
    bool sprawdzOkolice(int x, int y, int dlugosc, char orientacja);
    bool ustawStatek(int x, int y, int dlugosc, char orientacja);
    bool strzelaj(int x, int y);
    bool sprawdzCzyWszystkieStatkiZniszczone();
};

#endif