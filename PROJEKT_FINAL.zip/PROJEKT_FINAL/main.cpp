#include "Gracz.h"
#include "Plansza.h"
#include <iostream>
#include <vector>

// Funkcje pomocnicze
void wyczyscEkran() {
#ifdef _WIN32
    system("cls"); // Wyczyść ekran na Windows
#else
    system("clear"); 
#endif
}

void pauzaMiedzyTurami() {
    std::cout << "Naciśnij Enter, aby przekazać turę przeciwnikowi...";
    std::cin.ignore(); // Oczekiwanie na Enter
    std::cin.get();    // Kolejne oczekiwanie, gdy jest buforowane wejście
}

// Funkcja ustawiania statków dla gracza
void ustawStatkiDlaGracza(Gracz& gracz) {
    std::cout << gracz.imie << " - ustaw swoje statki.\n";
    gracz.ustawStatkiRęcznie();
    wyczyscEkran();
}

// Funkcja obsługi tury gracza
bool obsluzTure(Gracz& aktywnyGracz, Gracz& przeciwnik, int& tura) {
    std::cout << aktywnyGracz.imie << " - Twoja tura!\n";
    aktywnyGracz.plansza.wyswietlPlansze(false);

    int x, y;
    bool poprawne = false;
    while (!poprawne) {
        std::cout << "Podaj współrzędne do strzału (x y): ";
        std::cin >> x >> y;

        if (x >= 0 && x < 10 && y >= 0 && y < 10) {
            poprawne = true;
            if (aktywnyGracz.strzelajDoPrzeciwnika(x, y)) {
                if (przeciwnik.czyWszystkieStatkiZniszczone()) {
                    std::cout << "Gratulacje! " << aktywnyGracz.imie << " wygrał!\n";
                    return true; // Koniec gry
                } else {
                    std::cout << "Masz kolejną turę!\n";
                }
            } else {
                tura = (tura == 1) ? 2 : 1;
                pauzaMiedzyTurami();
                wyczyscEkran();
            }
        } else {
            std::cout << "Niepoprawne współrzędne! Wprowadź liczby od 0 do 9.\n";
        }
    }

    return false; // Gra trwa dalej
}

// Funkcja pojedynczej rozgrywki
bool rozgrywka(int& wygraneGracz1, int& wygraneGracz2) {
    Gracz gracz1("Gracz 1");
    Gracz gracz2("Gracz 2");

    // Ustawienie statków
    ustawStatkiDlaGracza(gracz1);
    ustawStatkiDlaGracza(gracz2);

    int tura = 1; // 1 dla Gracza 1, 2 dla Gracza 2
    bool czyKoniec = false;

    while (!czyKoniec) {
        Gracz& aktywnyGracz = (tura == 1) ? gracz1 : gracz2;
        Gracz& przeciwnik = (tura == 1) ? gracz2 : gracz1;

        czyKoniec = obsluzTure(aktywnyGracz, przeciwnik, tura);
    }

    if (tura == 1) {
        wygraneGracz1++;
    } else {
        wygraneGracz2++;
    }

    std::cout << "Czy chcesz zagrać ponownie? (T/N): ";
    char wybor;
    std::cin >> wybor;
    return !(wybor == 'N' || wybor == 'n'); // Zwraca true, jeśli gracz chce kontynuować
}

// Funkcja główna
int main() {
    int wygraneGracz1 = 0;
    int wygraneGracz2 = 0;
    bool grajPonownie = true;

    while (grajPonownie) {
        grajPonownie = rozgrywka(wygraneGracz1, wygraneGracz2);
        std::cout << "Wyniki:\n";
        std::cout << "Gracz 1: " << wygraneGracz1 << " wygranych\n";
        std::cout << "Gracz 2: " << wygraneGracz2 << " wygranych\n";
    }

    std::cout << "Dziękujemy za grę!" << std::endl;
    return 0;
}
