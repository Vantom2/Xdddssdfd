#include "Statek.h"

Statek::Statek(int dlugosc) : dlugosc(dlugosc) {}

void Statek::dodajPole(int x, int y) {
    pola.push_back(std::make_pair(x, y));
}
